import { ProxyOptions } from 'vite';
import {
  API_SYSTEM_URL,
  API_TARGET_URL_SYSTEM,
  API_APPLICATION_URL,
  API_DATACENTER_URL,
  API_RESOURCE_URL,
  API_TARGET_URL_APPLICATION,
  API_TARGET_URL_RESOURCE,
  API_TARGET_URL_DATACENTER,
  // API_BASE_URL,
  // BASE_TARGET_URL,
} from './constant';
type ProxyTargetList = Record<string, ProxyOptions>;

const init: ProxyTargetList = {
  // [API_BASE_URL]: {
  //   target: `${BASE_TARGET_URL}${API_BASE_URL}`,
  //   changeOrigin: true,
  //   // rewrite: (path) => path.replace(new RegExp(`^${API_BASE_URL}`), ''),
  // },
  // test
  [API_SYSTEM_URL]: {
    target: API_TARGET_URL_SYSTEM,
    changeOrigin: true,
  },
  [API_RESOURCE_URL]: {
    target: API_TARGET_URL_RESOURCE,
    changeOrigin: true,
  },
  [API_APPLICATION_URL]: {
    target: API_TARGET_URL_APPLICATION,
    changeOrigin: true,
  },
  [API_DATACENTER_URL]: {
    target: API_TARGET_URL_DATACENTER,
    changeOrigin: true,
  },
};

export default init;
