/**
 * @name Config
 * @description 项目配置
 */

// 应用名
export const APP_TITLE = 'vite-project';

// 本地服务端口
export const VITE_PORT = 8000;

// prefix
export const API_PREFIX = '/gaplatformweb-api';

// base server
export const API_BASE_URL = '/aicityweb-api';
export const BASE_TARGET_URL = 'https://10.254.50.1:9094';

// 本地开发调试时，非4A环境使用的ip（内网或者后端本地启动服务，可看情况修改）
export const testIp = 'http://172.31.30.112';

export const API_DATACENTER_URL = '/datacenter';
export const API_TARGET_URL_DATACENTER = `${testIp}:8888`;

export const API_RESOURCE_URL = '/resource';
export const API_TARGET_URL_RESOURCE = `${testIp}:8886`;

export const API_SYSTEM_URL = '/system';
export const API_TARGET_URL_SYSTEM = `${testIp}:8892`;

export const API_APPLICATION_URL = '/application';
export const API_TARGET_URL_APPLICATION = `${testIp}:8887`;

// 包依赖分析
export const ANALYSIS = true;

// 是否支持Md渲染
export const MARKDOWN = true;

// 代码压缩
export const COMPRESSION = true;

// 删除 console
export const VITE_DROP_CONSOLE = true;
