import fs from 'fs';
import { GitRevisionPlugin } from 'git-revision-webpack-plugin';
import path from 'path';
import { ConfigEnv } from 'vite';
import { VITE_PORT } from './vite/constant';
import { createVitePlugins } from './vite/plugins';
import proxy from './vite/proxy';

let branch = 'main';
try {
  const packageData = fs.readFileSync('./package.json', 'utf8');
  const parsedPackageData = JSON.parse(packageData);
  branch = `cloud_v${parsedPackageData.version}_release`;
} catch (err) {
  console.log('读取失败', err);
}

const gitRevision: any = new GitRevisionPlugin();

// https://vitejs.dev/config/
export default ({ command }: ConfigEnv) => {
  // 获取各种环境下的对应的变量
  const isBuild = command === 'build';
  return {
    base: '/public-tools/',
    plugins: createVitePlugins(isBuild),
    resolve: {
      alias: {
        '@': path.resolve('./src'), // 相对路径别名配置，使用 @ 代替 src
        '@home': path.resolve('./src/views/home/'), // 相对路径别名配置，使用 @home 代替 home
      },
    }, // scss全局变量配置
    css: {
      preprocessorOptions: {
        scss: {
          javascriptEnabled: true,
          additionalData: '@import "./src/styles/variable.scss";',
        },
      },
    },
    define: {
      // 注意要用 JSON.stringify
      'process.env.BRANCH': JSON.stringify(branch),
      'process.env.COMMITHASH': JSON.stringify(gitRevision.commithash()),
    },
    // server
    server: {
      hmr: { overlay: false }, // 禁用或配置 HMR 连接 设置 server.hmr.overlay 为 false 可以禁用服务器错误遮罩层
      // 服务配置
      port: VITE_PORT, // 类型： number 指定服务器端口;
      open: false, // 类型： boolean | string在服务器启动时自动在浏览器中打开应用程序；
      cors: false, // 类型： boolean | CorsOptions 为开发服务器配置 CORS。默认启用并允许任何源
      host: '0.0.0.0', // IP配置，支持从IP启动
      proxy,
      https: false,
    },
    build: {
      outDir: 'public-tools', // 在npm run build 时 ，生成文件的目录名称（要和baseUrl的生产环境路径一致）（默认dist）
      assetsDir: 'static',
    },
  };
};
