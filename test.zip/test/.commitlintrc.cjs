// .commitlintrc.js
module.exports = {
  // 扩展预设规则，这里使用的是 Conventional Commits 规范
  extends: ['@commitlint/config-conventional'],

  // 自定义规则，可以覆盖或添加新的规则
  rules: {
    // 类型只能是这几种
    'type-enum': [
      2, // 错误级别，2 表示如果违反规则将阻止提交
      'always', // 规则总是生效
      [
        // 允许的提交类型列表
        'feat', // 新功能
        'fix', // 修复 bug
        'docs', // 文档改动
        'style', // 不影响代码运行的样式修改，如空格、分号等
        'refactor', // 代码重构，不修改功能
        'perf', // 性能优化
        'test', // 测试用例的增加或修改
        'chore', // 构建过程或辅助工具的变动
        'revert', // 回滚上一次提交
        'workflow', // CI/CD 相关的变动
        'build', // 构建流程的修改，如发布版本、对项目构建或依赖的修改
      ],
    ],

    // 主题必须以冒号分隔符结尾
    'subject-full-stop': [1, 'never', '.'],

    // 主题不能超过 100 个字符
    'subject-max-length': [2, 'always', 100],

    // 主题必须以大写字母开头
    'subject-case': [2, 'never', ['upper-case', 'start-case']],

    // 可选范围
    'scope-empty': [0, 'always'],

    // 脚本必须以空行开始
    'header-max-length': [2, 'always', 100],

    // 禁止使用类型 "type()"
    'type-empty': [2, 'never'],
  },
};

// 你可以选择使用 JSON 格式的配置文件，只需要将扩展名改为 .json 即可
// 但是使用 .js 文件可以提供更高级的配置选项，如函数和动态配置
