// .lintstagedrc.js
module.exports = {
  '*.{js,jsx,ts,tsx}': ['prettier --write', 'eslint'],
  'package.json': ['prettier --write'],
  '*.vue': ['prettier --write', 'eslint'],
  '*.{scss,less,styl,html}': ['prettier --write'],
  '*.md': ['prettier --write'],
};
