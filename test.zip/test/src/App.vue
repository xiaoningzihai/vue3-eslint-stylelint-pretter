<template>
  <a-config-provider :locale="locale" :theme="theme">
    <router-view />
  </a-config-provider>
</template>

<script setup lang="ts">
// antd和dayjs 国际化中文
import zhCN from 'ant-design-vue/es/locale/zh_CN';

const locale = zhCN;
const theme = {
  token: {
    colorPrimary: '#2c8afb',
    colorWarning: '#f7852a',
    colorError: '#ff4d4f',
    // colorInfo: 'rgba(0, 0, 0, 0.45)',
    colorSuccess: '#27c82c',
    fontFamily: 'PingFang SC',
  },
};
</script>

<style scoped></style>
