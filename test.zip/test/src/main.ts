import { createApp } from 'vue';
import App from './App.vue';
import globalComponent from './components/index';
import './utils/rem';

import 'ant-design-vue/dist/reset.css';
// import 'animate.css';
import '@/styles/index.scss';
// svg插件需要配置代码
import 'virtual:svg-icons-register';
// 引入路由
import router from './router';
// 引入仓库
import 'core-js/stable';
import pinia from './store';
import './style.css';

const app = createApp(App);
// 安装自定义插件
app.use(globalComponent);
// 安装仓库
app.use(pinia);
// 注册模板路由
app.use(router);
// 引入路由鉴权文件 如果不需要login 直接注释下一行 不引入这个就跳转到route 中的 /
// import '@/router/permission';
// 将应用挂载到挂载点上
app.mount('#app');
